import './globals.css'
export const metadata = {
  title: 'RFX Visual Template',
  description: 'Premium Website Template',
}
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}